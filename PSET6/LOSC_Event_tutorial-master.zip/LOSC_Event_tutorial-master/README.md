# LOSC_Event_tutorial

The home for this is https://www.gwosc.org/tutorials/

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/losc-tutorial/LOSC_Event_tutorial/master?labpath=LOSC_Event_tutorial.ipynb)
